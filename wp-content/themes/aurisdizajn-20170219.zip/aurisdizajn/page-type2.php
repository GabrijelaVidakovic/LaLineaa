<?php
	// Template Name: Type 2

	if ( function_exists( 'wpcf7_enqueue_scripts' ) && is_page('narudzba') ) {
		wpcf7_enqueue_scripts();
	}

?>

<?php get_header(); ?>

<main class="main" role="main">
	<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
	<article>
		<h1 class="page-title"><?php the_title(); ?></h1>
		<div class="article-body type-2">
			<?php the_content(); ?>
		</div>
	</article>
	<?php endwhile; endif; ?>
</main>

<?php
	if(is_page('narudzba')) {
		$product_id = (int)$_GET['proizvod'];
		$product_link = get_permalink( $product_id );
		$product_title = get_the_title( $product_id );
?>
	<script>
		jQuery('#product').val('<?php echo $product_title ?>');
		jQuery('.wpcf7-form').prepend('<input type="hidden" name="product-url" value="<?php echo $product_link ?>" />');
	</script>
<?php } ?>

<?php get_sidebar(); ?>
<?php get_footer(); ?>
