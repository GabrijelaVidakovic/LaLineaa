<?php get_header(); ?>

<main class="main" role="main">
	<article>
		<h1 class="page-title">Pogreška 404</h1>
		<div class="article-body">
			<p>Žao nam je, ali ono što tražite ne nalazi se ovdje.</p>
		</div>
	</article>
</main>

<?php get_sidebar(); ?>
<?php get_footer(); ?>
