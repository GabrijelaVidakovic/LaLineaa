
		</div>
		<footer class="footer" role="contentinfo">
			<p>Copyright &copy; <?php echo date("Y"); ?>. <?php bloginfo('name'); ?></p>
		</footer>
	</div>
</div>
<?php wp_footer(); ?>
</body>
</html>
